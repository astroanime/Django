from django.apps import AppConfig


class FurnitureConfig(AppConfig):
    name = 'furniture'
