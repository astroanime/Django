from django.db import models


# Create your models here.
class Customer(models.Model):
    CATEGORY = (
        ('RICH', 'POOR'),
        ('ЧАСТЫЕ', 'РЕДКИЕ'),
    )

    name = models.CharField(max_length=200, null=True)
    phone = models.CharField(max_length=200, null=True)
    emails = models.CharField(max_length=200, null=True)
    order = models.CharField(max_length=300, null=True)
    date_created = models.TimeField(auto_now_add=True, null=True)

    def __str__(self):
        return self.name + " " + self.phone + " " + self.emails


class Stuff(models.Model):
    name = models.CharField(max_length=200, null=True)
    phone = models.CharField(max_length=200, null=True)
    emails = models.CharField(max_length=200, null=True)
    date_created = models.TimeField(auto_now_add=True, null=True)

    def __str__(self):
        return self.name + " " + self.phone + " " + self.emails


class Appointment(models.Model):
    service = models.CharField(max_length=200, null=True)
    stuff = models.ForeignKey(Stuff, on_delete=models.CASCADE, null=True)

    def __str__(self):
        return self.service


class Chair(models.Model):
    name = models.CharField(max_length=20)

    def __str__(self):
        return self.name


class Material(models.Model):
    name = models.CharField(max_length=20)
    chair = models.ForeignKey(Chair, on_delete=models.CASCADE)

    def __str__(self):
        return self.name


class Contact(models.Model):
    msg_id = models.AutoField(primary_key=True)
    message_name = models.CharField(max_length=50)
    message_email = models.CharField(max_length=70, default="")
    phone_number = models.CharField(max_length=70, default="")
    message = models.TextField(max_length=200, default="")

    def __str__(self):
        return self.message_name + " " + self.message_email + " " + self.phone_number
