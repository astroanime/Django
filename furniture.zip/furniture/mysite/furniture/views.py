from django.shortcuts import render, redirect
from django.conf import settings
from django.contrib import messages
from django.core.mail import send_mail
from .forms import CreateUserForm, CustomerForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.views.generic import ListView
from .models import Appointment, Stuff, Contact, Customer
from django.db import models


class AppointmentList(ListView):
    model = Appointment


def home(request):
    return render(request, 'home.html', {})


def sofas(request):
    return render(request, 'sofas.html', {})


def exclusive(request):
    return render(request, 'exclusive.html', {})


def collection(request):
    return render(request, 'collection.html', {})


def regis(request):
    form = CreateUserForm()

    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            form.save()
            user = form.cleaned_data.get('username')
            messages.success(request, 'Accaunt was created for ' + user)

            return redirect('login')
    context = {'form': form}
    return render(request, 'regis.html', context)


def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.info(request, 'Username or password is incorrect')
            return render(request, 'login.html', {})

    context = {}
    return render(request, 'login.html', context)


def logoutUser(request):
    logout(request)
    return redirect('home')


def contact(request):
    if request.method == "POST":
        message_name = request.POST['message-name']
        message_email = request.POST['message-email']
        message = request.POST['message']
        phone_number = request.POST['phone_number']
        contact = Contact(message_name=message_name, message_email=message_email,phone_number=phone_number, message=message)
        contact.save()
        customer = Customer(name=message_name, phone=phone_number,
                            order=message, emails=message_email)
        customer.save()
        appointment = "Name: " + message_name + " Email: " + \
            message_email + " Message: " + message + "Phone: " + phone_number

        if message is not None:
            send_mail(
                ('abeuov.o0705@gmail.com'),
                appointment,
                settings.EMAIL_HOST_USER,
                # To email
                ['abeuov.o0705@gmail.com'],
                fail_silently=False,
            ),

            return render(request, 'Order.html', {
                'message_name': message_name,
                'message_email': message_email,
                'message': message,
                'phone_number': phone_number,
            })
        else:
            messages.error(request, 'You need add something to make booking')
            return render(request, 'contact.html', {})

    else:
        return render(request, 'contact.html', {})


def OrderPage(request):
    return render(request, 'Order.html', {})


@login_required
def userPage(request, pk_test):
    Name = Customer.objects.get(id=pk_test)
    index = Stuff.objects.all()
    olzhas = {'Name': Name, 'index': index}

    return render(request, 'userPage.html', olzhas)


def createorder(request):
    form = CustomerForm()
    if request.method == "POST":
        #print('Printing POST:', request.POST)
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')

    context = {'form': form}
    return render(request, 'order_form.html', context)
