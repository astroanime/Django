from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('contact.html', views.contact, name="contact"),
    path('sofas.html', views.sofas, name="sofas"),
    path('exclusive.html', views.exclusive, name="exclusive"),
    path('collection.html', views.collection, name="collection"),
    path('regis.html', views.regis, name="regis"),
    path('login.html', views.loginPage, name="login"),
    path('Order.html', views.OrderPage, name="order"),
    path('home.html', views.logoutUser, name="logout"),
    path('userPage/<str:pk_test>/', views.userPage, name="userPage"),
    path('order_form.html', views.createorder, name="createorder" )
]
