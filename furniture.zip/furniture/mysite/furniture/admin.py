from django.contrib import admin
from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.contrib.auth.models import User

# Register your models here.
from .models import Customer, Appointment, Stuff, Chair, Material, Contact
admin.site.register(Customer)
admin.site.register(Appointment)
admin.site.register(Stuff)
admin.site.register(Chair)
admin.site.register(Material)
admin.site.register(Contact)

