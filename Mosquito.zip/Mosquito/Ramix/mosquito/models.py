from django.db import models

# Create your models here.
class Order(models.Model):
    msg_id = models.AutoField(primary_key=True)
    message_name = models.CharField(max_length=50)
    message_email = models.CharField(max_length=70, default="")
    phone_number = models.CharField(max_length=70, default="")


    def __str__(self):
        return self.message_name + " " + self.message_email +" " + self.phone_number
