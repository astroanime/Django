from django.urls import path
from . import views

urlpatterns = [
    path('home.html', views.home, name="home"),
    path('recovery.html', views.recovery, name="recovery"),
    path('registration.html', views.regis, name="regis"),
    path('auth.html', views.auth, name="auth"),
    path('order.html', views.order, name="order"),
    path('orderPage.html', views.orderpg, name="orderpg"),
    path('', views.hw, name="hw"),
] 
