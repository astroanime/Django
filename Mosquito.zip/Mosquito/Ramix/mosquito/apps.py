from django.apps import AppConfig


class MosquitoConfig(AppConfig):
    name = 'mosquito'
