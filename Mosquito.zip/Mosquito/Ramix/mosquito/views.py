from django.shortcuts import render, redirect
from django.conf import settings
from django.contrib import messages
from django.core.mail import send_mail
from .forms import CreateUserForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import Order 


# Create your views here.
def home(request):
    return render(request, 'home.html', {})

def hw(request):
    return render(request, 'hw.html', {})

def regis(request):
	form = CreateUserForm()

	if request.method == 'POST':
		form = CreateUserForm(request.POST)
		if form.is_valid():
			form.save()
            

			return redirect('home')
	context = {'form':form}
	return render(request, 'registration.html', context)

def recovery(request):
    return render(request, 'recovery.html', {})


def auth(request):
	if request.method == 'POST':
		username = request.POST.get('username')
		password = request.POST.get('password')

		user = authenticate(request, username=username, password=password)
		if user is not None:
			login(request, user)
			return redirect('home')
		else:
			messages.info(request, 'Username or password is incorrect')
			return render(request, 'auth.html', {})


	context = {}
	return render(request, 'auth.html', context)


	context = {}
	return render(request, 'auth.html', context)

def orderpg(request):
	if request.method == "POST":
		message_name = request.POST['message-name']
		message_email = request.POST['message-email']
		message = request.POST['message']
		phone_number = request.POST['phone_number']
		orderpg = Order(message_name=message_name, message_email=message_email, phone_number=phone_number)
		orderpg.save()
		appointment = "Name: " + message_name + " Email: " + message_email + " Message: " + message + "Phone: " + phone_number

		if message is not None:
			send_mail(
				('zhumakhan.amirzhan@gmail.com'),
				appointment,
				settings.EMAIL_HOST_USER,
				 #To email
				 ['zhumakhan.amirzhan@gmail.com'],
				 fail_silently=False,
				),
			
			return render(request, 'Order.html', {
				'message_name' : message_name,
				'message_email' : message_email,
				'message' : message,
				'phone_number' : phone_number, 
				})
		else:
			messages.error(request, 'You need add something to make booking')
			return render(request, 'orderPage.html', {})

	else:
		return render(request, 'orderPage.html', {})

def order(request):
	return render(request, 'order.html', {})
