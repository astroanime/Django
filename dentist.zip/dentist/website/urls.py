from django.urls import path, include
from .views import AppointmentList
from . import views


urlpatterns = [
    path('', views.home, name="home"),
   # path('appointment_list/', AppointmentList.as_view(), name="AppointmentList"),
    path('contact.html', views.contact, name="contact"),
    path('about.html', views.about, name="about"),
    path('pricing.html', views.pricing, name="pricing"),
    path('service.html', views.service, name="service"),
    path('regis.html', views.regis, name="regis"),
    path('login.html', views.loginPage, name="login"),
    path('meme.html', views.meme, name="meme"),
    path('appointment.html', views.appointment, name="appointment"),

]

