from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.contrib.auth.forms import UserCreationForm
from .forms import CreateUserForm
from django.forms import inlineformset_factory, modelformset_factory
from .models import Appointment, Stuff
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.views.generic import ListView
#from django.contrib.auth.decorators import login_required
#def appointment_list(request):
	#return render(request, 'appointment_list.html', {})
class AppointmentList(ListView):
	model = Appointment
def regis(request):
	form = CreateUserForm()

	if request.method == 'POST':
		form = CreateUserForm(request.POST)
		if form.is_valid():
			form.save()
			user = form.cleaned_data.get('username')
			messages.success(request, 'Accaunt was created for ' + user)

			return redirect('login')
	context = {'form':form}
	return render(request, 'regis.html', context)
def home(request):
	return render(request, 'home.html', {})
def meme(request):
	return render(request, 'meme.html', {})
def loginPage(request):
	if request.method == 'POST':
		username = request.POST.get('username')
		password = request.POST.get('password')

		user = authenticate(request, username=username, password=password)
		if user is not None:
			login(request, user)
			return redirect('home')
		else:
			messages.info(request, 'Username or password is incorrect')
			return render(request, 'login.html', {})


	context = {}
	return render(request, 'login.html', context)	
def logoutUser(request):
	logout(request)
	return redirect('loginPage')
def contact(request):
	if request.method == "POST":
		message_name = request.POST['message-name']
		message_email = request.POST['message-email']
		message = request.POST['message']
		your_schedule = request.POST['your-schedule']


		appointment = "Name: " + message_name + " Email: " + message_email + " Message: " + message + "Time: " + your_schedule

		if message is not None:
			send_mail(
				('abeuov.o0705@gmail.com'),
				appointment,
				settings.EMAIL_HOST_USER,
				 #To email
				 ['abeuov.o0705@gmail.com'],
				 fail_silently=False,
				),
		
			return render(request, 'appointment.html', {
				'message_name' : message_name,
				'message_email' : message_email,
				'message' : message,
				'your_schedule' : your_schedule 
				})
		else:
			messages.error(request, 'You need add something to make booking')
			return render(request, 'contact.html', {})

	else:
		return render(request, 'contact.html', {})



def about(request):
	return render(request, 'about.html', {})
def pricing(request):
	return render(request, 'pricing.html', {})

def service(request):
	return render(request, 'service.html', {})

def appointment(request):
	if request.method == "POST":
		your_name = request.POST['your-name']
		your_phone = request.POST['your-phone']
		your_email = request.POST['your-email']
		your_address = request.POST['your-address']
		your_schedule = request.POST['your-schedule']
		your_time = request.POST['your-time']
		your_message = request.POST['your-message']



		#send an email
		'''
		send_email(
			message_mail , # subject 
			message, # message
			message_mail, # from email
			['abeuov.o0705@gmail.com'], #To email
			)
'''
		return render(request, 'appointment.html', {'your_schedule'})

	else:
		return render(request, 'appointment.html', {})





	