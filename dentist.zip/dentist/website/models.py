from django.db import models


# Create your models here.
class Customer(models.Model):
	CATEGORY = (
			('RICH', 'POOR'),
			('ЧАСТЫЕ', 'РЕДКИЕ'),
			)

	name = models.CharField(max_length=200, null=True)
	phone = models.CharField(max_length=200, null=True)
	emails = models.CharField(max_length=200, null=True)
	date_created = models.TimeField(auto_now_add=True, null=True)
	def __str__(self):
		return self.name +" " + self.phone + " " + self.emails

class Stuff(models.Model):
	name = models.CharField(max_length=200, null=True)
	phone = models.CharField(max_length=200, null=True)
	emails = models.CharField(max_length=200, null=True)
	date_created = models.TimeField(auto_now_add=True, null=True)
	def __str__(self):
		return self.name +" " + self.phone + " " + self.emails

class Appointment(models.Model):
	service = models.CharField(max_length=200, null=True)
	stuff = models.ForeignKey(Stuff, on_delete=models.CASCADE, null=True)
	def __str__(self):
		return self.service

class Programmer(models.Model):
	name = models.CharField(max_length=20)
	def __str__(self):
		return self.name
class Language(models.Model):
	name = models.CharField(max_length=20)
	programmer = models.ForeignKey(Programmer, on_delete=models.CASCADE)
	def __str__(self):
		return self.name
class Appointment(models.Model):
	neme = models.CharField(max_length=20)